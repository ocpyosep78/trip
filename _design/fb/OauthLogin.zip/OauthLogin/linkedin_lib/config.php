<?php
//Linkedin Application Settings
$linkedin_appKey='App Key';
$linkedin_appSecret='App Secret';
$linkedin_callbackUrl=$base_url.'linkedin_login.php';
?>