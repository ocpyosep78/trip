<?php
//Microsoft Application Settings
$microsoft_client_id='Client ID';
$microsoft_client_secret='Client Secret';
$microsoft_scope='wl.basic wl.emails wl.birthday'; //Don't modify this
$microsoft_redirect_url=$base_url.'microsoft_login.php'; 
?>