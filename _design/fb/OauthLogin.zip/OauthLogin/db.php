<?php
$mysql_hostname = "localhost";
$mysql_user = "UserName";
$mysql_password = "password*";
$mysql_database = "Database";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");
$base_url='http://www.yourwebsite.com/';
?>